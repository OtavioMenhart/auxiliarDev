﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util.Config
{
   public abstract class ConfigurationUrl
    {
        public const string URL_APP = "http://localhost:8000";
        public const string URL_API = "http://localhost:4200";
    }
}
