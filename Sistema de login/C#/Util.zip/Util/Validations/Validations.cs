﻿using System;
using System.Text.RegularExpressions;

namespace Util.Validations
{
    public static class Validations
    {
        public static void StringEmpty(string value, string menssageError)
        {
            if (value == "")
            {
                throw new Exception(menssageError);
            }
        }

        public static void StringNull(string value, string menssageError)
        {
            if (value == null)
            {
                throw new Exception(menssageError);
            }
        }

        public static void ObjectNull(object value, string menssageError)
        {
            if (value == null)
            {
                throw new Exception(menssageError);
            }
        }

        public static void PassworMatch(string password, string confirm, string menssageError)
        {
            if (password != confirm)
            {
                throw new Exception(menssageError);
            }
        }

        public static void IdCheck(int number, string menssageError)
        {
            if (number <= 0)
            {
                throw new Exception(menssageError);
            }
        }

        public static void DateVerification(DateTime date, string menssageError)
        {
            if (date < new DateTime(1900,01,01))
            {
                throw new Exception(menssageError);
            }
        }

        public static void EmailVerification(string email, string menssageError)
        {
            Regex rg = new Regex(@"^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$");
            if (!(rg.IsMatch(email)))
            {
                throw new Exception(menssageError);
            }
        }

        public static void LengthVerify(string teste, int minLength = -1, int maxLeagth = -1)
        {
            if (minLength == -1 && maxLeagth == -1)
            {
                throw new Exception("Method is not being used properly!");
            }
            else
            {
                if(teste.Length < minLength ||  teste.Length > maxLeagth )
                {
                    throw new Exception("The number of characters is not allowed!");
                }
            }

            if (minLength != -1 && maxLeagth == -1)
            {
                if (teste.Length < minLength)
                {
                    throw new Exception("the minimum number of characters is not allowed!");
                }
            }

            if (maxLeagth != -1 && minLength == -1)
            {
                if (teste.Length > maxLeagth)
                {
                    throw new Exception("the maximum number of characters is not allowed!");
                }
            }

        }
    }
}
