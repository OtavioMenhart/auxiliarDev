﻿using System;
using System.IO;
using System.Web;

namespace Log
{
    public class SaveLog
    {
        private static string path = HttpContext.Current.Server.MapPath("~/log/");
        private static string strFile = HttpContext.Current.Server.MapPath("~/log/log_Erro.log");

        public static void InsertErrorLog(Exception erro)
        {

            if (!Directory.Exists(path))
            {
                DirectoryInfo di = Directory.CreateDirectory(path);
            }

            //Se arquivo não existir
            if (!File.Exists(strFile))
            {
                //Criar o arquivo, 
                //Estou usando o using para fazer o Dispose automático do arquivo após criá-lo.
                using (FileStream fs = File.Create(strFile)) { }
            }


            using (StreamWriter w = File.AppendText(strFile))
            {
                string _msg = string.Empty;
                string URL = HttpContext.Current.Request.Url.AbsoluteUri.ToString();

                //Adicionar um separador
                _msg = "#############################################################\r\n";
                //Data do erro
                _msg += "Data: " + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "\r\n";
                //URL do erro
                _msg += "URL: " + URL + "\r\n";
                _msg += "Tipo: " + erro.GetType().ToString() + "\r\n";
                //Adicionando a mensagem
                _msg += "Error: " + erro.Message;
                //quebra de lina e nova linha
                _msg += "\r\n";
                if (erro.InnerException != null)
                {
                    _msg += "Erro Interno: " + erro.InnerException.ToString() + "\r\n";
                }
                _msg += "Infos Adicionais: " + erro.StackTrace.ToString() + "\r\n";
                //Escreve no arquivo
                w.Write(_msg);
                //Fecha
                w.Close();
            }
        }

    }
}
