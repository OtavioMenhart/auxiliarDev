﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Util.Cryptography
{
    public class Crypto
    {

        private HashAlgorithm _algoritmo = RIPEMD160.Create();
        private static string guidAdd = "653295bb659a445f93fcf54b914e0ce8";


        public string GerarSenha(string senha)
        {
            var valorCodificado = Encoding.UTF8.GetBytes(senha);
            var senhaCifrada = _algoritmo.ComputeHash(valorCodificado);
            var sb = new StringBuilder();
            foreach (var caractere in senhaCifrada)
            {
                sb.Append(caractere.ToString("X2"));
            }
            return sb.ToString();
        }
        public bool VerificarSenha(string senhaDigitada, string senhaCadastrada)
        {
            var senhaCifrada = _algoritmo.ComputeHash(Encoding.UTF8.GetBytes(senhaDigitada));
            var sb = new StringBuilder();
            foreach (var caractere in senhaCifrada)
            {
                sb.Append(caractere.ToString("X2"));
            }
            return sb.ToString() == senhaCadastrada;
        }


    

    ////Method using to Encode, you can use internal, public, private...
    //public static string Encode(string passwordEncode)
    //{
    //    var concat = String.Format("{0}{1}", passwordEncode,guidAdd);
    //    var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(passwordEncode);
    //    return System.Convert.ToBase64String(plainTextBytes);
    //}

    ////Method using to Decode, you can use internal, public, private...
    //public static string Base64Decode(string base64EncodedData)
    //{
    //    var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
    //    var convert = System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
    //    var value = convert.Replace(guidAdd,"");
    //    return value;
    //}





}
}
