<?php
class ClasseQualquer extends Crud {
    protected $table = "NOME DA TABELA DO BANCO";
    //put your code here
    public function insert() {
        
    }

    public function update() {
        
    }
    
}