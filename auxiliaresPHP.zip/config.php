<?php
//coloque aqui as informações do banco
define('DB_Host', '');
define('DB_Nome', '');
define('DB_User', '');
define('DB_Pass', '');
