<?php
include('Crud.php');
include('ClasseQualquer.php');

//crie um objeto da sua classe
$obj = new ClasseQualquer();
?>