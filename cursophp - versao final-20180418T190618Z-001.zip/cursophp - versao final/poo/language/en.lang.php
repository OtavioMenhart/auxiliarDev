﻿<?php
/* arquivo de tradução em inglês */

class Lang {
	const MENSAGEM_DE_BOAS_VINDAS = "Welcome!"; 
	const MENSAGEM_DE_SAIDA_DO_SISTEMA = "Good bye!";
}