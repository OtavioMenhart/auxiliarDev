﻿<?php
/* arquivo de tradução em portugues */

class Lang {
	const MENSAGEM_DE_BOAS_VINDAS = "Seja bem vindo ao nosso sistema!";
	const MENSAGEM_DE_SAIDA_DO_SISTEMA = "Até breve!";
}