<?php 

include("classes/log.class.php");
include("classes/_login.class.php");

$login = new Login();
$login->logar("jaison");
