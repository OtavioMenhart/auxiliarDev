﻿<html>
	<head>
		<title><?=$titulo?></title>
	</head>
	<body>
		<h1>Aguarde, se download iniciará em breve...</h1>
	</body>
</html>