﻿<?php
	require_once("controller.php");
	require_once("view.php");