﻿<html>

	<head>
		<title><?=$titulo?></title>
	</head>
	<body>
		<h1>Dados de usuário:</h1>
		<p>Nome: <?=$nome?> / Idade : <?=$idade?> / Data de nascimento : <?=$dtNasc?></p>
		<h3><?=$mensagem?></h3>
		<p><?=$funcao?></p>
		<p>As palavras concatenadas são: <?=$concatenei?></p>
	</body>
</html>