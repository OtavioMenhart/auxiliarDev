﻿<html>
	<head>
		<title><?=$titulo?></title>
	</head>
	<body>
		<h1>Conexão com o banco MySQL</h1>
		<p><?=$resultado?></p>
	</body>
</html>