<html>
	<head>
		<title>Aula 02 - Curso de PHP</title>
	</head>
	<body>
		
		<?php 
			// phpinfo();
			echo "<h1>Hello World!</h1>";
		
		?>
		
	</body>
</html>