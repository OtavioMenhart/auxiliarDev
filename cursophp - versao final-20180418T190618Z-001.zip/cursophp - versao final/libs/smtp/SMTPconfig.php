<?php
	$SmtpServer="mail.jaison.com.br";
	$SmtpPort=26;
	$SmtpUser="php@jaison.com.br";
	$SmtpPass="123@abc!";